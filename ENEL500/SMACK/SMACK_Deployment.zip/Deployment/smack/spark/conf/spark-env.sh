#!/bin/bash

# Java Home
export JAVA_HOME="$(env JAVA_HOME)" 
# Python for PySpark
export PYSPARK_PYTHON="python3.5"
