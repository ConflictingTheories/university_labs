#!/bin/bash
#
# hadoop-jobnode
#
# Install Hadoop and Configure for Job Tracking
# -- Note this has no SPARK -- 
# ---- Just Hadoop
#