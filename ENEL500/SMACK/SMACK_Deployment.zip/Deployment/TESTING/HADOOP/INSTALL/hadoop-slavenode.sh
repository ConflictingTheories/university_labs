#!/bin/bash
#
# hadoop-slavenode
#
# Install and Configure Hadoop for Working Nodes
# This Requires Task Tracking and Working
#
# This will also have slave Spark nodes installed
# and configured for to be used
# 