#!/bin/bash
#
# hadoop-namenode
#
# Install And Configure Name Node (MASTER)
# and Additionally, install and Configure Spark (MASTER)
#
# * Requires Slaves Being Configured?
#